#! python3


def GetUrlsAndPaths(IniFile):

    import configparser
    import logging
    import inspect
    import sys

    # ********************************************************************************************************
    # * Set up logging
    # * To turn on logging, set root_logger.disabled = False
    # * To turn off logging, set root_logger.disabled = True
    # ********************************************************************************************************
    root_logger = logging.getLogger()
    root_logger.disabled = True  # Set to false to see debugging info
    logging.basicConfig(level=logging.DEBUG, format=' %(asctime)s - %(levelname)s - %(message)s')

    if root_logger.disabled == False:
        file_name = inspect.stack()[0][3] # This is slow, so only run it when logging
        called_from = lambda n=1: sys._getframe(n + 1).f_code.co_name
        logging.debug('Start of ' + file_name + ' function' + " Called from: " + called_from.__module__)

    config = configparser.ConfigParser()
    config.sections()
    config.read(IniFile)

    PgmSettings = {'Header': config['URLs']['Header']}
    PgmSettings['Rebates'] = config['URLs']['Rebates']
    PgmSettings['PDFPath'] = config['PDFPaths']['pdfpath']

    logging.debug('RebateHeaderUrl:' + PgmSettings['Header'])
    logging.debug('RebatePDFUrl:' + PgmSettings['Header'])
    logging.debug('RebatePDFUrl:' + PgmSettings['PDFPath'])


    return PgmSettings

if __name__ == '__main__':

    RebateHeaderUrl = ''
    RebatePDFUrl = ''
    data={}
    data = GetUrlsAndPaths(r'C:\Users\Public\Documents\Python\MenardsRebate\MenardsSettings.ini')
